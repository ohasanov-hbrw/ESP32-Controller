#include <Arduino.h>


#include <BleGamepad.h>


#define number_of_74hc595s 2
#define numOfRegisterPins number_of_74hc595s * 8
#define SER_Pin 27
#define RCLK_Pin 14
#define SRCLK_Pin 12

void setRegisterPin(int,int);
void clearRegisters();
void writeRegisters();

bool buttons[16] = {false, false, false, false,
                    false, false, false, false,
                    false, false, false, false,
                    false, false, false, false};

bool registers [16] = {false, false, false, false,
                    false, false, false, false,
                    false, false, false, false,
                    false, false, false, false};


BleGamepad bleGamepad;


void setup() {
  pinMode(32, INPUT);
  pinMode(32, INPUT);
  pinMode(33, INPUT);
  pinMode(34, INPUT);
  pinMode(35, INPUT);
  pinMode(2, INPUT_PULLUP);
  pinMode(26, INPUT_PULLUP);

  pinMode(5, INPUT);
  pinMode(16, INPUT);

  pinMode(SER_Pin, OUTPUT);
  pinMode(RCLK_Pin, OUTPUT);
  pinMode(SRCLK_Pin, OUTPUT);

  clearRegisters();
  writeRegisters();
  delay(500);
  BleGamepadConfiguration bleGamepadConfig;
  bleGamepadConfig.setAutoReport(false);
  bleGamepad.begin(&bleGamepadConfig);
  setCpuFrequencyMhz(80);
}

void loop() {
  for(int i = numOfRegisterPins-1; i >=  8; i--){
    setRegisterPin(i, HIGH);
    setRegisterPin(i-8, HIGH);
    writeRegisters();
    buttons[i] = digitalRead(5);
    buttons[i-8] = digitalRead(16);
    setRegisterPin(i, LOW);
    setRegisterPin(i-8, LOW);
    writeRegisters(); 
  }
  /*
  A 14
  B 12
  X 13
  Y 15
  */
  if(bleGamepad.isConnected()){
    if(buttons[0])
      bleGamepad.press(BUTTON_8);
    else
      bleGamepad.release(BUTTON_8);

    if(buttons[1])
      bleGamepad.press(BUTTON_6);
    else
      bleGamepad.release(BUTTON_6);

    if(buttons[2])
      bleGamepad.press(BUTTON_5);
    else
      bleGamepad.release(BUTTON_5);

    if(buttons[3])
      bleGamepad.press(BUTTON_7);
    else
      bleGamepad.release(BUTTON_7);

    if(buttons[14])
      bleGamepad.press(BUTTON_2);
    else
      bleGamepad.release(BUTTON_2);

    if(buttons[12])
      bleGamepad.press(BUTTON_3);
    else
      bleGamepad.release(BUTTON_3);

    if(buttons[13])
      bleGamepad.press(BUTTON_1);
    else
      bleGamepad.release(BUTTON_1);

    if(buttons[15])
      bleGamepad.press(BUTTON_4);
    else
      bleGamepad.release(BUTTON_4);

    if(buttons[8])
      bleGamepad.press(BUTTON_13);
    else
      bleGamepad.release(BUTTON_13);

    if(buttons[11])
      bleGamepad.press(BUTTON_14);
    else
      bleGamepad.release(BUTTON_14);

    if(buttons[9])
      bleGamepad.press(BUTTON_9);
    else
      bleGamepad.release(BUTTON_9);

    if(buttons[10])
      bleGamepad.press(BUTTON_10);
    else
      bleGamepad.release(BUTTON_10);

    if(!digitalRead(26))
      bleGamepad.press(BUTTON_11);
    else
      bleGamepad.release(BUTTON_11);

    if(!digitalRead(2))
      bleGamepad.press(BUTTON_12);
    else
      bleGamepad.release(BUTTON_12);
    bleGamepad.sendReport();

    int x1 = map(analogRead(33),0,4095, -6, 6);
    x1++;
    if(x1 > 5) x1=5;
    int X1 = map(x1,-5,5, -32767, 32767);
    int y1 = map(analogRead(32),0,4095, -6, 6);
    y1++;
    if(y1 > 5) y1=5;
    int Y1 = map(y1,-5,5, -32767, 32767);

    int x2 = map(analogRead(34),0,4095, -6, 6);
    x2++;
    if(x2 > 5) x2=5;
    int X2 = map(x2,-5,5, 32767, -32767);
    int y2 = map(analogRead(35),0,4095, -6, 6);
    y2++;
    if(y2 > 5) y2=5;
    int Y2 = map(y2,-5,5, -32767, 32767);

    if(!buttons[4] && !buttons[5] && !buttons[6] && !buttons[7])
      bleGamepad.setHat1(DPAD_CENTERED);
    else if(buttons[7] && !buttons[5] && !buttons[6])
      bleGamepad.setHat1(DPAD_UP);
    else if(buttons[4] && !buttons[5] && !buttons[6])
      bleGamepad.setHat1(DPAD_DOWN);
    else if(buttons[5] && !buttons[7] && !buttons[4])
      bleGamepad.setHat1(DPAD_LEFT);
    else if(buttons[6] && !buttons[7] && !buttons[4])
      bleGamepad.setHat1(DPAD_RIGHT);
    else if(buttons[7] && buttons[5])
      bleGamepad.setHat1(DPAD_UP_LEFT);
    else if(buttons[7] && buttons[6])
      bleGamepad.setHat1(DPAD_UP_RIGHT);
    else if(buttons[4] && buttons[5])
      bleGamepad.setHat1(DPAD_DOWN_LEFT);
    else if(buttons[4] && buttons[6])
      bleGamepad.setHat1(DPAD_DOWN_RIGHT);
    bleGamepad.setAxes(X1, Y1, X2, Y2, 0, 0, 0, 0);
  }
}

void setRegisterPin(int index,int value){
  registers[index] = value;
}

void clearRegisters(){ 
  for(int i = numOfRegisterPins-1; i >=  0; i--){
    registers[i] = HIGH;
  }
}

void writeRegisters(){
  digitalWrite(RCLK_Pin, LOW);
  for(int i = numOfRegisterPins-1; i >=  0; i--){
    digitalWrite(SRCLK_Pin, LOW); int val = registers[i];
    digitalWrite(SER_Pin, val);
    digitalWrite(SRCLK_Pin, HIGH);
  }
  digitalWrite(RCLK_Pin, HIGH);
}